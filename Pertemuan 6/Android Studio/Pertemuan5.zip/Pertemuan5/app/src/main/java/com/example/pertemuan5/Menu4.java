package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Menu4 extends AppCompatActivity {

    //deklarsi variabel global disini
    EditText Text_Ang;
    TextView Hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu4);


        //panggil object berdasarkan ID
        Text_Ang = findViewById(R.id.int_ang);
        Hasil = findViewById(R.id.Cetak_Hasil);

    }

    public void Cetak_Nilai(View v) {
        int a = Integer.parseInt(Text_Ang.getText().toString());
        int x = 1;
        int y = x * x;
        while (y != a) {
            x = x + 1;
            y = x * x;

            Hasil.setText("Akar dari :" + x);
        }
    }
}
