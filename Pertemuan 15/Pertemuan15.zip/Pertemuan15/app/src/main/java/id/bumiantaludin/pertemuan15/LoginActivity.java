package id.bumiantaludin.pertemuan15;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    EditText UserName;
    EditText Password;
    Button Login;
    Button Keluar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        UserName = findViewById(R.id.editUsername);
        Password = findViewById(R.id.editPassword);
    }

    public void Login (View v){
        String username = UserName.getText().toString();
        String password = Password.getText().toString();
        if(username.equals("Admin") && password.equals("Admin")){
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            LoginActivity.this.startActivity(intent);
            finish();
        }else {
            Toast.makeText(this, "Username dan Password Salah", Toast.LENGTH_LONG). show();
        }
    }

    public void Keluar(View V){
        finish();
    }
}
