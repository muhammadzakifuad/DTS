package id.bumiantaludin.pertemuan13a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Sec_Activity extends AppCompatActivity {
    EditText nim;
    EditText nama;
    TextView c_nim;
    TextView c_nama;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec_);


        nim = findViewById(R.id.edit_nim);
        nama = findViewById(R.id.edit_nama);
        c_nim = findViewById(R.id.cetak_nim);
        c_nama = findViewById(R.id.cetak_nama);

    }

    public void CETAK(View v){
        c_nim.setText("NIM : " + nim.getText().toString());
        c_nama.setText("NAMA : " + nama.getText());
    }


}
