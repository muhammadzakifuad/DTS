package com.example.pertemuan9a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText nim;
    EditText nama;
    EditText kampus;
    TextView cetaknim;
    TextView cetaknama;
    TextView cetakkampus;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nim = findViewById(R.id.edit_nim);
        nama = findViewById(R.id.edit_nama);
        kampus = findViewById(R.id.edit_kampus);
        cetaknim = findViewById(R.id.cetak_nim);
        cetaknama = findViewById(R.id.cetak_nama);
        cetakkampus = findViewById(R.id.cetak_kampus);

    }

    public void CETAK (View v) {
        cetaknim.setText("Nim anda : " + nim.getText());
        cetaknama.setText("Nama anda: " + nama.getText());
        cetakkampus.setText("Kampus anda :"+ kampus.getText());
    }


}
