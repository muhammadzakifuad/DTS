package com.example.pertemuan8a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class GenapGanjil extends AppCompatActivity {
    EditText input_angka;
    TextView cetak;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_genap_ganjil);

        input_angka = findViewById(R.id.input_angka);
        cetak = findViewById(R.id.hasil_gg);
    }

    public void Cetak_GG (View v) {
        int x = Integer.parseInt(input_angka.getText().toString());
        if((x % 2 == 0)){
            cetak.setText("Bilangan "+x+" adalah bilangan Genap");
        } else {
            cetak.setText("Bilangan "+x+" adalah bilangan Ganjil");
        }
    }

}
