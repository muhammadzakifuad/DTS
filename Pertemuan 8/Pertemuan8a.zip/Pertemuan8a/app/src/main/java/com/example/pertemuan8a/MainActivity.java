package com.example.pertemuan8a;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.InputDevice;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText Inputa;
    EditText Inputb;
    TextView Btn_Hasil;
    TextView Btn_Tambah;
    TextView Btn_Kurang;
    TextView Btn_Kali;
    TextView Btn_Bagi;
    TextView Nilai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Inputa = findViewById(R.id.input1);
        Inputb = findViewById(R.id.input2);
        Btn_Hasil = findViewById(R.id.button);
        Btn_Tambah = findViewById(R.id.tambah);
        Btn_Kurang = findViewById(R.id.kurang);
        Btn_Kali = findViewById(R.id.kali);
        Btn_Bagi = findViewById(R.id.kali);
        Nilai = findViewById(R.id.hasil_angka);
    }
        public void Tambahkan(View v) {
            if (Inputa.getText().length() > 0 && Inputb.getText().length() > 0) {
                int input1 = Integer.parseInt(Inputa.getText().toString());
                int input2 = Integer.parseInt(Inputb.getText().toString());
                int hasil = input1 + input2;
                Nilai.setText(Integer.toString(hasil));
            } else {
                Toast toast = Toast.makeText(MainActivity.this, "Mohon Masukkan", Toast.LENGTH_LONG);
                toast.show();
            }
        }


            public void Kurangkan (View v) {
                if (Inputa.getText().length() > 0 && Inputb.getText().length() > 0) {
                    int input1 = Integer.parseInt(Inputa.getText().toString());
                    int input2 = Integer.parseInt(Inputb.getText().toString());
                    int hasil = input1 - input2;
                    Nilai.setText(Integer.toString(hasil));
                } else {
                    Toast toast = Toast.makeText(MainActivity.this, "Mohon Masukkan", Toast.LENGTH_LONG);
                    toast.show();
                }
            }

        public void Kalikan (View v) {
            if (Inputa.getText().length() > 0 && Inputb.getText().length() > 0) {
                int input1 = Integer.parseInt(Inputa.getText().toString());
                int input2 = Integer.parseInt(Inputb.getText().toString());
                int hasil = input1 * input2;
                Nilai.setText(Integer.toString(hasil));
             } else {
            Toast toast = Toast.makeText(MainActivity.this, "Mohon Masukkan", Toast.LENGTH_LONG);
            toast.show();
            }
        }

        public void Bagikan (View v) {
            if (Inputa.getText().length() > 0 && Inputb.getText().length() > 0) {
                int input1 = Integer.parseInt(Inputa.getText().toString());
                int input2 = Integer.parseInt(Inputb.getText().toString());
                int hasil = input1 / input2;
                Nilai.setText(Integer.toString(hasil));
        } else {
            Toast toast = Toast.makeText(MainActivity.this, "Mohon Masukkan", Toast.LENGTH_LONG);
            toast.show();
        }
    }

    public void Bersihkan (View v) {
        Inputa.setText(" ");
        Inputb.setText(" ");
        Nilai.setText(" ");

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu,menu);
        return  true;
    }

    public  boolean onOptionsItemSelected(MenuItem item){
        if (item.getItemId()==R.id.gg){
            startActivity(new Intent(this,GenapGanjil.class));
        }
        return true;
    }
}
