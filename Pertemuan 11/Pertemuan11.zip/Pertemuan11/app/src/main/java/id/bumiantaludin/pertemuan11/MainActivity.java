package id.bumiantaludin.pertemuan11;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper databasehelper;
    private Button BtnStore;
    private Button BtnGetAll;
    private EditText EtName;
    private TextView TvNames;
    private ArrayList<String> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databasehelper = new DatabaseHelper(this);
        TvNames = findViewById(R.id.tvnames);
        BtnStore = findViewById(R.id.btnstore);
        BtnGetAll = findViewById(R.id.btnget);
        EtName = findViewById(R.id.etname);
    }

    public void SimpanData(View v){
        databasehelper.insertData(EtName.getText().toString());
        EtName.setText("");
        Toast.makeText(MainActivity.this, "Stored Succesfully", Toast.LENGTH_SHORT).show();
    }

    public void TampilData(View v){
        arrayList = databasehelper.getAllDataList();
        TvNames.setText("");
        for (int i = 0; i < arrayList.size(); i++){
            TvNames.setText(TvNames.getText().toString()+ ", "+arrayList.get(i));
        }
    }
}
